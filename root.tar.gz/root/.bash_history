lsblk
apt install openssh-server
clear
nano /etc/ssh/sshd_config
systemctl restart ssh
ip a
shutdown now
clear
mkdir /usr/bin/.videos
mkdir archivos_tp
cd archivos_tp/
ls
find / -type d -name *videos
systemctl stop rsyslog
systemctl disable rsyslog
apt purge --auto-remove -y rsyslog
rm -rf /etc/rsyslog.conf /etc/rsyslog.d /var/spool/rsyslog
dpkg -l | grep rsyslog
systemctl status rsyslog
clear
userdel -r matias
gropus matias
ls /home/matias
clear
nano /opt/.servidorweb
apache2 → servidor web Apache2
mariadb-server → servidor de base de datos MariaDB
php libapache2-mod-php → soporte PHP para Apache2
php-mysql → conector PHP para MySQL/MariaDB
apt install apache2 mariadb-server php libapache2-mod-php php-mysql
mariadb < db.sql
cp index.php /var/www/html/index.php
nano index.php
systemctl restart apache2
nano index.php
cp index.php /var/www/html/index.php
systemctl stop apache2 mariadb
apt purge --auto-remove -y apache2 mariadb-server php libapache2-mod-php php-mysql
rm -rf /etc/apache2 /var/www/html /etc/mysql /var/lib/mysql /etc/php /var/lib/php
dpkg -l | grep -E 'apache2|mariadb|php'
clear
apt install apache2 mariadb-server php libapache2-mod-php php-mysql
mariadb < db.sql
cp index.php /var/www/html/index.php
systemctl restart apache2
systemctl stop apache2 mariadb
apt purge --auto-remove -y apache2 mariadb-server php libapache2-mod-php php-mysql
rm -rf /etc/apache2 /var/www/html /etc/mysql /var/lib/mysql /etc/php /var/lib/php
dpkg -l | grep -E 'apache2|mariadb|php'
clear
apt install apache2 mariadb-server php libapache2-mod-php php-mysql
cp index.php /var/www/html/index.php
mariadb < db.sql
clear
systemctl stop apache2 mariadb
apt purge --auto-remove -y apache2 mariadb-server php libapache2-mod-php php-mysql
rm -rf /etc/apache2 /var/www/html /etc/mysql /var/lib/mysql /etc/php /var/lib/php
# 1. Eliminar manualmente las carpetas que no estaban vacías
rm -rf /etc/php /var/www /etc/mysql /var/lib/mysql
# 2. Limpiar paquetes huérfanos o residuos que hayan quedado en el sistema
apt autoremove --purge -y
apt clean
# 1. Eliminar manualmente las carpetas que no estaban vacías
rm -rf /etc/php /var/www /etc/mysql /var/lib/mysql
# 2. Limpiar paquetes huérfanos o residuos que hayan quedado en el sistema
apt autoremove --purge -y
apt clean
rm -rf /etc/apache2 /var/www/html /etc/mysql /var/lib/mysql /etc/php /var/lib/php
dpkg -l | grep -E 'apache2|mariadb|php'
clear
cd ..
adduser matias
clear
mkdir /home/matias/.papelera_estudiante
su matias
nano /home/matias/.bashrc
su - matias
nano /home/matias/.bashrc
su - matias
clear
nano /home/matias/.bashrc
su - matias
chown matias /home/matias/.papelera_estudiante/
su - matias
find -type d -name crontab
find / -type d -name crontab
find / -type d -name *cron*
cd /var/spool/cron/crontabs
ls
cd matias
rm matias
ls
cd ..
cd..
userdel -rf matias
ls /home/matias
clear
cd
apt install gcc
sytemctl status rsyslog
systemctl status rsyslog
clear
nano zombies.c
gcc -o zombies.c zombies
gcc -o zombies zombies.c
./zombies
find / -type f -name *servidor*
top
clear
ps -ef
kill -47151
kill -9 47151
clear
find / -type f -name *servidor*
./zombies
ps -ef
kill -9 47170
clear
nano zombies.c
gcc -o zombies zombies.c
./zombies
ps aux
clear
ps -ef
kill -9 47196
clear
rm zombies
nano zombies.c
gcc -o romero zombies.c
./romero
ps aux
clear
cp romero archivos_tp/
rm romero
nano archivos_tp/romero
nano zombies.c
gcc -o romero zombies.c
./romero
ps aux
clear
ps -ef
kill -9 47268
kill -9 47223
clear
mv romero archivos_tp/
ls
rm zombies.c
cd archivos_tp
apt purge --autoremove nano
naon /etc/apt/sources.list
vi /etc/apt/sources.list
apt install nano
apt install vim
clear
vi /etc/apt/sources.list
apt install nano
apt install lynx
apt purge --autoremove nano
clar
clear
apt install nano
apt update
apt install nano
vi /etc/apt/sources.list
apt update
clear
apt install nano
clear
cd ..
cat /etc/network/interfaces
exit
ip a
find / -type d -name *videos
clear
cd /var/www
apt purge --autoremove openssh-server
clear
rm -rf /etc/ssh
rm -rf /etc/.ssh /home/*/.ssh
dpkg -l | grep openssh
apt clean
dpkg -l | grep openssh
clear
apt purge -y openssh-client openssh-sftp-server
dpkg -purge $(dpkg -l | grep "openssh" | awk "{print $2}")
dpkg --purge $(dpkg -l | grep "openssh" | awk "{print $2}")
clear
dpkg -l | grep openssh
apt purge openssh-client
dpkg -l | grep openssh
clear
find /etc/ -type d -name *ssh*
su - matias
cat /etc/groups
cat /etc/group
clear
vi /bin/stamp.sh
chmod +x /bin/stamp.sh
stamp
stamp.sh
vi /bin/stamp.sh
stamp.sh
vi /bin/stamp.sh
stamp.sh
cat /var/.stamp
cat /var/.stamp
reboot now
cat /var/.stamp
nano /bin/stamp.sh
vi /bin/stamp.sh
stamp.sh
cat /var/.stamp
mv /bin/stamp.sh /etc/.stamp.sh
clear
vi /etc/rc.local
ls /etc/rc.local
vi /etc/profile
chmod 777 /var/.stamp
chmod 777 /etc/.stamp.sh
reboot now
cat /var/.stamp
date
shutdown
ls
cd archivos_tp/
ls
cd ..
ls -la
hostname
cat /etc/hosts
hostnamectl set-hostname TPServer
hostname
vi /etc/hosts
cat /etc/hostname
cat /etc/hosts
exit
hostname
cat /etc/hosts
cat /etc/debian_version
cat /etc/os-release
uname -r
ip a
cat /etc/network/interfaces
dhclient enp0s2
ip a show enp0s2
ping -c 3 deb.debian.org
cat /etc/apt/sources.list
apt update
cp /etc/apt/sources.list /etc/apt/sources.list.bak
vi /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt upgrade --without-new-pkgs
apt full-upgrade
systemctl reboot
cat /etc/debian_version
cat /etc/os-release
uname -r
dhclient enp0s2
systemctl status ssh
ls -l /root/archivos_tp
apt install openssh-server nano
systemctl status ssh
ls -la /root/.ssh
cp /root/archivos_tp/clave_publica.pub /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
ls -la /root/.ssh
grep PermitRootLogin /etc/ssh/sshd_config
grep PubkeyAuthentication /etc/ssh/sshd_config
grep PasswordAuthentication /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
systemctl restart ssh
grep PermitRootLogin /etc/ssh/sshd_config
systemctl status ssh
systemctl poweroff
dhclient enp0s2
nano /etc/ssh/sshd_config
systemctl restart ssh
grep PermitRootLogin /etc/ssh/sshd_config
grep PubkeyAuthentication /etc/ssh/sshd_config
grep PasswordAuthentication /etc/ssh/sshd_config
systemctl is-active ssh
systemctl status rsyslog
ls -l /var/log/auth.log
apt install rsyslog
systemctl status rsyslog
ls -l /var/log/auth.log
tail -n 6 /var/log/auth.log
find / -name "*servidorweb*" 2>/dev/null
cat /opt/.servidorweb
apt install apache2 mariadb-server php libapache2-mod-php php-mysql
systemctl is-active apache2
systemctl is-active mariadb
php -v
ls -l /var/www/html
cp /root/archivos_tp/index.php /var/www/html/
mv /var/www/html/index.html /var/www/html/index.html.bak
ls -l /var/www/html
ls -l /root/archivos_tp/logo.png
cp /root/archivos_tp/logo.png /var/www/html/
ls -l /var/www/html
mariadb -e "SHOW DATABASES;"
mariadb < /root/archivos_tp/db.sql
mariadb -e "SHOW DATABASES;"
mariadb -e "SELECT user, host FROM mysql.user;"
mariadb -u computacion -paplicada ca_jueves -e "SELECT id, banda, archivo_mp4 FROM videos;"
cat /etc/network/interfaces
ip a show enp0s2
nano /etc/network/interfaces
cat /etc/resolv.conf
systemctl reboot
ip a show enp0s2
ip route
ping -c 2 10.0.0.1
ping -c 2 deb.debian.org
lsblk
fdisk -l /dev/sdb
fdisk /dev/sdb
fdisk /dev/sdb
mkfs.ext4 /dev/sdb1
mkfs.ext4 /dev/sdb2
lsblk -f /dev/sdb
mkdir /www_dir /backup_dir
mount /dev/sdb1 /www_dir
cp /var/www/html/index.php /var/www/html/logo.png /www_dir/
df -h /www_dir
ls -l /www_dir
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
grep -A 4 "<Directory /var/www/>" /etc/apache2/apache2.conf
nano /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/apache2.conf
apache2ctl configtest
systemctl restart apache2
systemctl is-active apache2
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
cat /etc/fstab
blkid /dev/sdb1 /dev/sdb2
nano /etc/fstab
systemctl daemon-reload
umount /www_dir
mount -a
df -h | grep sdb
ls -l /opt
cat /proc/partitions > /opt/particion
cat /opt/particion
systemctl reboot
uptime
df -h | grep sdb
systemctl is-active apache2
ls /www_dir
lsblk
df -h /www_dir /backup_dir
id estudiante
ls -l /home
adduser estudiante
id estudiante
grep estudiante /etc/passwd
ls -l /home
ls -ld /root
su estudiante -c "ls /root"
su estudiante -c "borrar"
apt install acl
mkdir /root/.delete_files_estudiante
chown estudiante:estudiante /root/.delete_files_estudiante
chmod 700 /root/.delete_files_estudiante
setfacl -m u:estudiante:x /root
getfacl /root
ls -ld /root/.delete_files_estudiante
nano /usr/local/bin/borrar
chown root:estudiante /usr/local/bin/borrar
chmod 750 /usr/local/bin/borrar
ls -l /usr/local/bin/borrar
su - estudiante
ls -la /root/.delete_files_estudiante
ls -l /etc/cron.allow /etc/cron.deny
su estudiante -c "crontab -l"
nano /etc/cron.deny
cat /etc/cron.deny
su estudiante -c "crontab -l"
su estudiante -c "crontab -e"
top
ps -el | grep Z
ls -l /root/archivos_tp
file /root/archivos_tp/romero
strings /root/archivos_tp/romero | grep Romero
strings /root/archivos_tp/romero | grep zombie
/root/archivos_tp/romero &
ps -ef | grep Romero
ps -el | grep Z
top
kill -9 920
ps -el | grep Z
ps -fp 919
kill 919
ps -el | grep Z
ps -ef | grep Romero
top
crontab -l
ls /etc/cron.d /etc/cron.daily
ls -l /etc/rc.local
ls /etc/systemd/system/multi-user.target.wants
ls /etc/profile.d
tail -n 3 /etc/profile
cat /etc/.stamp.sh
grep -r romero /etc /root/.bashrc /root/.profile
chmod -x /root/archivos_tp/romero
ls -l /root/archivos_tp/romero
/root/archivos_tp/romero
ls -l /opt
ls -l /backup_dir
crontab -l
mkdir /opt/scripts
nano /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
ls -l /opt/scripts
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /var/log
/opt/scripts/backup_full.sh /noexiste /backup_dir
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls -lh /backup_dir
tar -tzf /backup_dir/www_dir_bkp_*.tar.gz
umount /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
umount /www_dir
/opt/scripts/backup_full.sh /www_dir /tmp
mount -a
df -h /www_dir /backup_dir
crontab -e
crontab -l | tail -n 5
systemctl is-active cron
systemctl reboot
ps -el | grep Z
top
find / -name auth.log 2>/dev/null
grep "session opened for user root" /var/log/auth.log | grep -v cron | tail -n 1
grep "Accepted publickey for root" /var/log/auth.log | tail -n 1
grep "session opened for user estudiante" /var/log/auth.log | tail -n 1
grep "session opened for user root" /var/log/auth.log | grep -v cron | grep -v systemd | tail -n 1
grep "Accepted publickey for root" /var/log/auth.log | tail -n 1
grep "session opened for user estudiante" /var/log/auth.log | grep -v systemd | tail -n 1
last -n 6
lsb_release -a
cat /etc/debian_version
uname -r
uname -m
cat /proc/sys/kernel/pid_max
ulimit -u
df -h -x tmpfs -x devtmpfs
