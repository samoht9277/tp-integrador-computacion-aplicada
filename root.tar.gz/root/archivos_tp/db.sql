SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

CREATE DATABASE IF NOT EXISTS ca_jueves DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'computacion'@'localhost' IDENTIFIED BY 'aplicada';
CREATE USER IF NOT EXISTS 'computacion'@'127.0.0.1' IDENTIFIED BY 'aplicada';
GRANT ALL PRIVILEGES ON ca_jueves.* TO 'computacion'@'localhost';
GRANT ALL PRIVILEGES ON ca_jueves.* TO 'computacion'@'127.0.0.1';
FLUSH PRIVILEGES;

USE ca_jueves;

DROP TABLE IF EXISTS videos;

CREATE TABLE videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    banda VARCHAR(255) NOT NULL,
    tema VARCHAR(255) NOT NULL,
    archivo_mp4 VARCHAR(255) NOT NULL,
    youtube_id VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO videos (banda, tema, archivo_mp4, youtube_id) VALUES
('CSNZ LATINO', 'Linux: La película 🤯', 'linux.mp4', 'Gl3a9fAJ4OQ'),
('Ricky Martin', '#! 💥', 'ricky_martin.mp4', 'q5lDG9Wmc_4'),
('Daft Punk', 'Give Life Back to Music 🪩', 'daft_punk.mp4', 'IluRBvnYMoY'),
('Bôa', 'Duvet 🌐', 'boa.mp4', 'Uoox9fpmDP0'),
('Nirvana', 'Smells Like Teen Spirit 🎸', 'nirvana.mp4', 'KtALJ97XMw0'),
('Omar Courtz', 'SKY ☁️', 'omar_courtz.mp4', 'DQVlpdyAu6c'),
('Black Country, New Road', 'The Place Where He Inserted the Blade 🔪', 'bcnr.mp4', '1yhFejiKMkE'),
('Taylor Swift', 'All Too Well (Taylor''s Version) 🧣', 'taylor_swift.mp4', '9OQBDdNHmXo'),
('Luis Alberto Spinetta', 'Bajan (En Vivo) ft. Gustavo Cerati ☀️', 'spinetta.mp4', 'bZcMPnY9_dg'),
('Patricio Rey y sus Redonditos de Ricota', 'Tarea Fina 💎', 'tarea_fina.mp4', 'QB3qtA5hpCc'),
('Patricio Rey y sus Redonditos de Ricota', 'Ya nadie va a escuchar tu remera 👕', 'remera.mp4', 'jxPM0H_SrmQ'),
('Metallica', 'Sad But True 💀', 'metallica.mp4', 'A8MO7fkZc5o'),
('Rod Stewart', 'Young Turks 🕺', 'rod_stewart.mp4', 'DJZZZPBnMDM'),
('Airbag', 'Pensamientos 💭', 'airbag.mp4', '6gDGFfrOMdI'),
('Sabrina Carpenter', 'Manchild 👶', 'sabrina_carpenter.mp4', 'aSugSGCC12I'),
('The Beatles', 'Good Night 😴', 'beatles.mp4', 'Qp_djIuQ2Cw');
