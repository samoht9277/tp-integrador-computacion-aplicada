#!/bin/bash
# backup_full.sh - backup comprimido (.tar.gz) de un directorio
# Uso: backup_full.sh ORIGEN DESTINO
#      backup_full.sh -help

ayuda() {
    echo "Uso: backup_full.sh ORIGEN DESTINO"
    echo ""
    echo "Genera un backup .tar.gz del directorio ORIGEN dentro de DESTINO."
    echo "El archivo se llama NOMBRE_bkp_AAAAMMDD.tar.gz, por ejemplo:"
    echo "  backup_full.sh /var/log /backup_dir  ->  /backup_dir/log_bkp_20240302.tar.gz"
    echo ""
    echo "Antes de empezar valida que el origen y el destino existan y que,"
    echo "si son puntos de montaje de /etc/fstab, esten montados."
    echo ""
    echo "Opciones:"
    echo "  -help    muestra esta ayuda"
}

# valida que el directorio exista y que su sistema de archivos este disponible
validar() {
    if [ ! -d "$1" ]; then
        echo "Error: $2 $1 no existe o no es un directorio"
        exit 1
    fi
    # si esta definido como punto de montaje en fstab, tiene que estar montado
    if grep -q "[[:space:]]$1[[:space:]]" /etc/fstab && ! mountpoint -q "$1"; then
        echo "Error: el sistema de archivos de $1 no esta montado"
        exit 1
    fi
}

if [ "$1" = "-help" ]; then
    ayuda
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: faltan argumentos"
    ayuda
    exit 1
fi

ORIGEN=$1
DESTINO=$2

validar "$ORIGEN" "el origen"
validar "$DESTINO" "el destino"

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

echo "$(date '+%F %T') Backup de $ORIGEN en $ARCHIVO"
tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"
if [ $? -le 1 ]; then
    echo "$(date '+%F %T') Backup terminado: $(du -h "$ARCHIVO" | cut -f1)"
else
    echo "$(date '+%F %T') Error al generar el backup"
    exit 1
fi
