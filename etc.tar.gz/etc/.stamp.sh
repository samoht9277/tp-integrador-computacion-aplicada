#!/bin/bash

FECHA=$(date "+%Y-%m-%d %H:%M:%S")

HASH=$(echo "BOOT_$(date +%s%N)_$RANDOM" | sha256sum | awk '{print $1}')

echo "Fecha: $FECHA" > /var/.stamp
echo "Hash_Sesion: $HASH" >> /var/.stamp

chmod 644 /var/.stamp
